/* =========================================================
   RUTAS DE RECOLECCIÓN NORMAL
========================================================= */

const rutas = [

    // =========================
    // RUTA 1 - LMV
    // =========================
    {
        ruta: "Ruta 1",
        dias: ["Lunes", "Miércoles", "Viernes"],
        horarios: [
            { hora: "5:30 a.m.", barrio: "Plaza de Mercado" },
            { hora: "6:30 a.m.", barrio: "Obrero 1" },
            { hora: "7:30 a.m.", barrio: "Obrero 2" },
            { hora: "8:30 a.m.", barrio: "Las Ceibas" },
            { hora: "9:30 a.m.", barrio: "Corralito de Piedra" },
            { hora: "10:30 a.m.", barrio: "Carrera 25" },
            { hora: "12:00 p.m.", barrio: "El Puerto (Centro)" }
        ]
    },


    // =========================
    // RUTA 1 - MJS
    // =========================
    {
        ruta: "Ruta 1",
        dias: ["Martes", "Jueves", "Sábado"],
        horarios: [
            { hora: "5:30 a.m.", barrio: "Las Américas" },
            { hora: "6:00 a.m.", barrio: "Los Pinos" },
            { hora: "6:30 a.m.", barrio: "San Martín" },
            { hora: "7:00 a.m.", barrio: "Villa Docente" },
            { hora: "7:30 a.m.", barrio: "Somaito" },
            { hora: "8:00 a.m.", barrio: "11 de Enero" },
            { hora: "8:30 a.m.", barrio: "Centenario" },
            { hora: "9:00 a.m.", barrio: "Sinaí" },
            { hora: "9:30 a.m.", barrio: "San Nicolás" },
            { hora: "10:30 a.m.", barrio: "El Puerto (Centro)" },
            { hora: "11:00 a.m.", barrio: "Carmen" },
            { hora: "12:00 p.m.", barrio: "Modelo" }
        ]
    },


    // =========================
    // RUTA 2 - LMV
    // =========================
    {
        ruta: "Ruta 2",
        dias: ["Lunes", "Miércoles", "Viernes"],
        horarios: [
            { hora: "5:30 a.m.", barrio: "Alvernia" },
            { hora: "6:00 a.m.", barrio: "Altos del Cedral" },
            { hora: "7:00 a.m.", barrio: "Chiparos" },
            { hora: "8:00 a.m.", barrio: "Colina" },
            { hora: "9:00 a.m.", barrio: "Kennedy" },
            { hora: "10:00 a.m.", barrio: "Recreo" },
            { hora: "11:00 a.m.", barrio: "Camilo Torres" },
            { hora: "12:00 p.m.", barrio: "Allende" }
        ]
    },


    // =========================
    // RUTA 2 - MJS
    // =========================
    {
        ruta: "Ruta 2",
        dias: ["Martes", "Jueves", "Sábado"],
        horarios: [
            { hora: "5:00 a.m.", barrio: "Buenos Aires" },
            { hora: "5:30 a.m.", barrio: "Prado" },
            { hora: "6:00 a.m.", barrio: "San Fernando" },
            { hora: "6:30 a.m.", barrio: "Luis Carlos Galán 1" },
            { hora: "7:00 a.m.", barrio: "Luis Carlos Galán 2" },
            { hora: "7:30 a.m.", barrio: "Luis Carlos Galán 3" },
            { hora: "8:00 a.m.", barrio: "Caracolí" },
            { hora: "8:30 a.m.", barrio: "Los Olivos" },
            { hora: "9:00 a.m.", barrio: "Ciudad Leguizamo" },
            { hora: "10:00 a.m.", barrio: "Villa Paz 1 y 2" },
            { hora: "11:00 a.m.", barrio: "Casa del Comfamiliar" },
            { hora: "11:30 a.m.", barrio: "Villa Rosa" },
            { hora: "12:00 p.m.", barrio: "Trébol" }
        ]
    },


    // =========================
    // RUTA 3 - LMV
    // =========================
    {
        ruta: "Ruta 3",
        dias: ["Lunes", "Miércoles", "Viernes"],
        horarios: [
            { hora: "5:30 a.m.", barrio: "Colina Campestre" },
            { hora: "6:00 a.m.", barrio: "Floresta" },
            { hora: "6:30 a.m.", barrio: "Los Cristales" },
            { hora: "7:00 a.m.", barrio: "20 de Julio" },
            { hora: "7:30 a.m.", barrio: "San Francisco" },
            { hora: "7:30 a.m.", barrio: "Hong Kong (La Playa)" },
            { hora: "8:30 a.m.", barrio: "Tequendama" },
            { hora: "9:00 a.m.", barrio: "Los Lagos" },
            { hora: "10:00 a.m.", barrio: "Metropolitano" },
            { hora: "11:00 a.m.", barrio: "3 de Mayo" },
            { hora: "12:00 p.m.", barrio: "La Pista" }
        ]
    },


    // =========================
    // RUTA 3 - MJS
    // =========================
    {
        ruta: "Ruta 3",
        dias: ["Martes", "Jueves", "Sábado"],
        horarios: [
            { hora: "5:30 a.m.", barrio: "Acevedo" },
            { hora: "6:30 a.m.", barrio: "Simón Bolívar" },
            { hora: "7:30 a.m.", barrio: "El Jardín" },
            { hora: "8:30 a.m.", barrio: "Jorge Eliécer Gaitán" },
            { hora: "9:30 a.m.", barrio: "Montañita" },
            { hora: "10:30 a.m.", barrio: "Londres" },
            { hora: "11:00 a.m.", barrio: "Vía Disposición Final" }
        ],

        nota: "Únicamente los días jueves se realizará la recolección de residuos sólidos en la vía Muelle La Esmeralda."
    },


    // =========================
    // RUTA 3 - MIÉRCOLES Y SÁBADOS
    // =========================
    {
        ruta: "Ruta 3",
        dias: ["Miércoles", "Sábado"],
        horarios: [
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "La Esperanza" },
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "Santana" },
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "Batallón Santana" },
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "Batallón Km 5" },
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "Peñazora" },
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "Batallón Gaula" },
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "I.E. San Francisco de Asís" },
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "Cootransmayo" },
            { hora: "5:30 a.m. - 10:00 a.m.", barrio: "Estación de Servicio Km 3" }
        ]
    }

];



/* =========================================================
   RUTA SELECTIVA DE RECICLAJE
========================================================= */

const rutasReciclaje = [

    // =========================
    // LUNES - SECTOR 6
    // =========================
    {
        dia: "Lunes",
        sector: "Sector 6",
        horarios: [
            { hora: "7:00 AM - 7:30 AM", barrio: "Ciudad Leguizamo" },
            { hora: "7:30 AM - 7:50 AM", barrio: "Los Olivos" },
            { hora: "7:50 AM - 9:00 AM", barrio: "Luis Carlos Galán" },
            { hora: "9:00 AM - 9:30 AM", barrio: "Centro - Puente Los Cabrera / El Puerto - Zona Rosa - Carrera 25" },
            { hora: "9:30 AM - 9:40 AM", barrio: "Vía al Hospital con salida a la Bomba Romo" },
            { hora: "10:10 AM - 10:40 AM", barrio: "Villa Paz I y II" },
            { hora: "10:40 AM - 11:00 AM", barrio: "Altos de Comfamiliar" },
            { hora: "11:00 AM - 11:40 AM", barrio: "Villa Rosa" },
            { hora: "11:40 AM - 12:00 PM", barrio: "Ciudadela Amazónica" },
            { hora: "12:00 PM - 12:30 PM", barrio: "El Trébol" },
            { hora: "12:30 PM - 1:00 PM", barrio: "Londres" },
            { hora: "1:00 PM - 1:30 PM", barrio: "La Montañita" }
        ]
    },


    // =========================
    // MARTES - SECTOR 2
    // =========================
    {
        dia: "Martes",
        sector: "Sector 2",
        horarios: [
            { hora: "7:00 AM - 7:25 AM", barrio: "Alvernia" },
            { hora: "7:25 AM - 7:40 AM", barrio: "Altos de Cedral" },
            { hora: "7:40 AM - 8:00 AM", barrio: "Los Chiparos" },
            { hora: "8:00 AM - 8:30 AM", barrio: "Las Colinas" },
            { hora: "8:30 AM - 9:00 AM", barrio: "Kennedy" },
            { hora: "9:00 AM - 9:30 AM", barrio: "Centro - Puente Los Cabrera / El Puerto - Zona Rosa - Carrera 25" },
            { hora: "9:30 AM - 9:40 AM", barrio: "Vía al Hospital con salida a la Bomba Romo" },
            { hora: "10:15 AM - 10:40 AM", barrio: "Colina Campestre" },
            { hora: "10:40 AM - 11:00 AM", barrio: "San Fernando" },
            { hora: "11:00 AM - 11:30 AM", barrio: "Los Cristales" },
            { hora: "11:30 AM - 12:00 PM", barrio: "La Floresta" },
            { hora: "12:00 PM - 12:25 PM", barrio: "Corralito de Piedra" }
        ]
    },


    // =========================
    // MIÉRCOLES - SECTOR 4
    // =========================
    {
        dia: "Miércoles",
        sector: "Sector 4",
        horarios: [
            { hora: "7:00 AM - 7:30 AM", barrio: "Buenos Aires" },
            { hora: "7:30 AM - 8:30 AM", barrio: "El Prado" },
            { hora: "8:30 AM - 9:00 AM", barrio: "San Nicolás" },
            { hora: "9:00 AM - 9:30 AM", barrio: "Centro - Puente Los Cabrera / El Puerto - Zona Rosa - Carrera 25" },
            { hora: "9:30 AM - 9:40 AM", barrio: "Vía al Hospital con salida a la Bomba Romo" },
            { hora: "10:10 AM - 10:40 AM", barrio: "El Carmen" },
            { hora: "10:40 AM - 11:00 AM", barrio: "Modelo" },
            { hora: "11:00 AM - 11:40 AM", barrio: "Jorge Eliécer Gaitán" },
            { hora: "11:40 AM - 12:10 PM", barrio: "Jardín" },
            { hora: "12:10 PM - 12:50 PM", barrio: "Simón Bolívar" },
            { hora: "12:50 PM - 1:30 PM", barrio: "Acevedo" }
        ]
    },


    // =========================
    // JUEVES - SECTOR 3
    // =========================
    {
        dia: "Jueves",
        sector: "Sector 3",
        horarios: [
            { hora: "6:30 AM - 7:30 AM", barrio: "Corregimiento de Santana" },
            { hora: "7:30 AM - 8:30 AM", barrio: "Tres de Mayo" },
            { hora: "8:30 AM - 9:00 AM", barrio: "Metropolitano" },
            { hora: "9:00 AM - 9:30 AM", barrio: "Centro - Puente Los Cabrera / El Puerto - Zona Rosa - Carrera 25" },
            { hora: "9:30 AM - 9:40 AM", barrio: "Vía al Hospital con salida a la Bomba Romo" },
            { hora: "10:10 AM - 10:40 AM", barrio: "Poblado" },
            { hora: "10:40 AM - 11:00 AM", barrio: "Nuevo Horizonte" },
            { hora: "11:00 AM - 11:40 AM", barrio: "Tequendama" },
            { hora: "11:40 AM - 12:10 PM", barrio: "Ciudadela Comfamiliar" },
            { hora: "12:10 PM - 1:00 PM", barrio: "Los Lagos" }
        ]
    },


    // =========================
    // VIERNES - SECTOR 5
    // =========================
    {
        dia: "Viernes",
        sector: "Sector 5",
        horarios: [
            { hora: "7:00 AM - 7:40 AM", barrio: "Las Américas" },
            { hora: "7:40 AM - 8:10 AM", barrio: "Villa Docente" },
            { hora: "8:10 AM - 8:30 AM", barrio: "Nuevo Amanecer" },
            { hora: "8:30 AM - 9:00 AM", barrio: "San Martín" },
            { hora: "9:00 AM - 9:30 AM", barrio: "Centro - Puente Los Cabrera / El Puerto - Zona Rosa - Carrera 25" },
            { hora: "9:30 AM - 9:40 AM", barrio: "Vía al Hospital con salida a la Bomba Romo" },
            { hora: "10:15 AM - 10:40 AM", barrio: "Sinaí" },
            { hora: "10:40 AM - 11:00 AM", barrio: "Centenario" },
            { hora: "11:00 AM - 11:30 AM", barrio: "11 de Enero" },
            { hora: "11:30 AM - 12:00 PM", barrio: "Las Palmas" },
            { hora: "12:00 PM - 12:25 PM", barrio: "Somaito" },
            { hora: "12:25 PM - 1:00 PM", barrio: "Los Pinos" }
        ]
    },


    // =========================
    // SÁBADO - SECTOR 1
    // =========================
    {
        dia: "Sábado",
        sector: "Sector 1",
        horarios: [
            { hora: "7:00 AM - 7:30 AM", barrio: "20 de Julio" },
            { hora: "7:30 AM - 9:00 AM", barrio: "Obrero I - Obrero II" },
            { hora: "9:00 AM - 9:30 AM", barrio: "Centro - Puente Los Cabrera / El Puerto - Zona Rosa - Carrera 25" },
            { hora: "9:30 AM - 9:40 AM", barrio: "Vía al Hospital con salida a la Bomba Romo" },
            { hora: "10:10 AM - 10:40 AM", barrio: "Las Ceibas" },
            { hora: "10:40 AM - 11:00 AM", barrio: "Camilo Torres" },
            { hora: "11:00 AM - 11:20 AM", barrio: "Recreo" },
            { hora: "11:20 AM - 11:40 AM", barrio: "Allende" },
            { hora: "11:40 AM - 12:30 PM", barrio: "Los Lagos" }
        ]
    }

];



/* =========================================================
   ELEMENTOS DEL HTML
========================================================= */

const contenedorRutas =
    document.getElementById("contenedorRutas");

const contenedorReciclaje =
    document.getElementById("contenedorReciclaje");

const botonesDias =
    document.querySelectorAll(".boton-dia");

const buscarBarrio =
    document.getElementById("buscarBarrio");

const formBusqueda =
    document.getElementById("formBusqueda");

const mostrarTodos =
    document.getElementById("mostrarTodos");



/* =========================================================
   VARIABLES DE FILTRO
========================================================= */

let diaSeleccionado = "";

let textoBusqueda = "";



/* =========================================================
   NORMALIZAR TEXTO
   Permite buscar con o sin tildes.
========================================================= */

function normalizarTexto(texto) {

    return texto
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .toLowerCase()
        .trim();

}



/* =========================================================
   CREAR TARJETA DE RECOLECCIÓN
========================================================= */

function crearTarjetaRuta(
    ruta,
    horariosFiltrados = ruta.horarios
) {

    const tarjeta =
        document.createElement("article");

    tarjeta.classList.add("tarjeta-ruta");


    const cabecera =
        document.createElement("div");

    cabecera.classList.add(
        "tarjeta-ruta-cabecera"
    );


    const titulo =
        document.createElement("h4");

    titulo.textContent =
        ruta.ruta;


    const dias =
        document.createElement("p");

    dias.textContent =
        ruta.dias.join(", ");


    cabecera.appendChild(titulo);
    cabecera.appendChild(dias);


    const tabla =
        document.createElement("table");

    tabla.classList.add(
        "tabla-horarios"
    );


    tabla.innerHTML = `
        <thead>

            <tr>
                <th>Hora</th>
                <th>Barrio</th>
            </tr>

        </thead>

        <tbody>

            ${horariosFiltrados
                .map(
                    horario => `
                        <tr>
                            <td>
                                ${horario.hora}
                            </td>

                            <td>
                                ${horario.barrio}
                            </td>
                        </tr>
                    `
                )
                .join("")}

        </tbody>
    `;


    tarjeta.appendChild(cabecera);
    tarjeta.appendChild(tabla);


    if (ruta.nota) {

        const nota =
            document.createElement("div");

        nota.classList.add(
            "nota-ruta"
        );

        nota.innerHTML = `
            <strong>Nota:</strong>
            ${ruta.nota}
        `;

        tarjeta.appendChild(nota);
    }


    return tarjeta;

}



/* =========================================================
   MOSTRAR RUTAS
========================================================= */

function renderizarRutas() {

    contenedorRutas.innerHTML = "";


    const busquedaNormalizada =
        normalizarTexto(textoBusqueda);


    const resultados = rutas

        .filter(ruta => {

            if (!diaSeleccionado) {
                return true;
            }

            return ruta.dias.includes(
                diaSeleccionado
            );

        })


        .map(ruta => {

            let horariosFiltrados =
                ruta.horarios;


            if (busquedaNormalizada) {

                horariosFiltrados =
                    ruta.horarios.filter(
                        horario =>
                            normalizarTexto(
                                horario.barrio
                            ).includes(
                                busquedaNormalizada
                            )
                    );

            }


            return {
                ruta,
                horariosFiltrados
            };

        })


        .filter(
            resultado =>
                resultado.horariosFiltrados
                    .length > 0
        );


    if (resultados.length === 0) {

        contenedorRutas.innerHTML = `
            <div class="sin-resultados">

                <h4>
                    No encontramos resultados
                </h4>

                <p>
                    Revisa el nombre del barrio
                    o selecciona otro día.
                </p>

            </div>
        `;

        return;
    }


    resultados.forEach(resultado => {

        const tarjeta =
            crearTarjetaRuta(
                resultado.ruta,
                resultado.horariosFiltrados
            );

        contenedorRutas.appendChild(
            tarjeta
        );

    });

}



/* =========================================================
   CREAR TARJETA DE RECICLAJE
========================================================= */

function crearTarjetaReciclaje(ruta) {

    const tarjeta =
        document.createElement("article");

    tarjeta.classList.add(
        "tarjeta-ruta"
    );


    const cabecera =
        document.createElement("div");

    cabecera.classList.add(
        "tarjeta-ruta-cabecera"
    );


    const titulo =
        document.createElement("h4");

    titulo.textContent =
        ruta.dia;


    const sector =
        document.createElement("span");

    sector.classList.add(
        "badge-sector"
    );

    sector.textContent =
        ruta.sector;


    cabecera.appendChild(titulo);
    cabecera.appendChild(sector);


    const tabla =
        document.createElement("table");

    tabla.classList.add(
        "tabla-horarios"
    );


    tabla.innerHTML = `
        <thead>

            <tr>
                <th>Hora</th>
                <th>Barrios</th>
            </tr>

        </thead>

        <tbody>

            ${ruta.horarios
                .map(
                    item => `
                        <tr>
                            <td>
                                ${item.hora}
                            </td>

                            <td>
                                ${item.barrio}
                            </td>
                        </tr>
                    `
                )
                .join("")}

        </tbody>
    `;


    tarjeta.appendChild(cabecera);
    tarjeta.appendChild(tabla);


    return tarjeta;

}



/* =========================================================
   MOSTRAR RUTA SELECTIVA
========================================================= */

function renderizarReciclaje() {

    if (!contenedorReciclaje) {
        return;
    }


    contenedorReciclaje.innerHTML = "";


    const rutasFiltradas =
        rutasReciclaje.filter(ruta => {

            if (!diaSeleccionado) {
                return true;
            }

            return ruta.dia ===
                diaSeleccionado;

        });


    if (rutasFiltradas.length === 0) {

        contenedorReciclaje.innerHTML = `
            <div class="sin-resultados">

                <h4>
                    No hay ruta selectiva
                    para este día
                </h4>

                <p>
                    Selecciona otro día para
                    consultar la ruta de reciclaje.
                </p>

            </div>
        `;

        return;
    }


    rutasFiltradas.forEach(ruta => {

        const tarjeta =
            crearTarjetaReciclaje(ruta);

        contenedorReciclaje.appendChild(
            tarjeta
        );

    });

}



/* =========================================================
   BAJAR EXACTAMENTE A HORARIOS DE RECOLECCIÓN
========================================================= */

function bajarARutas() {

    const seccionRutas =
        document.getElementById("rutas");

    const encabezado =
        document.querySelector(
            ".encabezado"
        );


    if (!seccionRutas) {
        return;
    }


    /*
       Buscamos específicamente el título
       dentro de la sección de rutas.
    */

    const objetivo =
        seccionRutas.querySelector(
            ".titulo-resultados"
        ) || seccionRutas;


    const alturaEncabezado =
        encabezado
            ? encabezado.offsetHeight
            : 0;


    const posicionObjetivo =
        objetivo
            .getBoundingClientRect()
            .top
        + window.scrollY
        - alturaEncabezado
        - 20;


    window.scrollTo({
        top: posicionObjetivo,
        behavior: "smooth"
    });

}



/* =========================================================
   FILTRAR POR DÍA
========================================================= */

botonesDias.forEach(boton => {

    boton.addEventListener(
        "click",
        () => {

            const dia =
                boton.dataset.dia;


            /*
               Si pulsa otra vez el mismo
               día, se deselecciona.
            */

            if (
                diaSeleccionado === dia
            ) {

                diaSeleccionado = "";

                boton.classList.remove(
                    "activo"
                );

            } else {

                diaSeleccionado = dia;


                botonesDias.forEach(
                    botonDia => {

                        botonDia
                            .classList
                            .remove(
                                "activo"
                            );

                    }
                );


                boton.classList.add(
                    "activo"
                );

            }


            renderizarRutas();

            renderizarReciclaje();

        }
    );

});



/* =========================================================
   CAMPO DE BÚSQUEDA

   Mientras escribe guardamos el texto,
   pero no desplazamos automáticamente.
========================================================= */

buscarBarrio.addEventListener(
    "input",
    evento => {

        textoBusqueda =
            evento.target.value;

    }
);



/* =========================================================
   BOTÓN BUSCAR / ENTER

   1. Ejecuta el filtro.
   2. Espera a que el HTML cambie.
   3. Baja exactamente a "Horarios de recolección".
========================================================= */

if (formBusqueda) {

    formBusqueda.addEventListener(
        "submit",
        evento => {

            evento.preventDefault();


            textoBusqueda =
                buscarBarrio
                    .value
                    .trim();


            renderizarRutas();


            /*
               Dos requestAnimationFrame garantizan
               que el navegador ya terminó de
               actualizar el tamaño de los resultados
               antes de calcular el desplazamiento.
            */

            requestAnimationFrame(() => {

                requestAnimationFrame(() => {

                    bajarARutas();

                });

            });

        }
    );

}



/* =========================================================
   MOSTRAR TODAS LAS RUTAS
========================================================= */

mostrarTodos.addEventListener(
    "click",
    () => {

        diaSeleccionado = "";

        textoBusqueda = "";


        buscarBarrio.value = "";


        botonesDias.forEach(
            boton => {

                boton.classList.remove(
                    "activo"
                );

            }
        );


        renderizarRutas();

        renderizarReciclaje();


        requestAnimationFrame(() => {

            requestAnimationFrame(() => {

                bajarARutas();

            });

        });

    }
);



/* =========================================================
   CARGA INICIAL
========================================================= */

renderizarRutas();

renderizarReciclaje();